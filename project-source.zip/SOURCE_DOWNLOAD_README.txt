Project source download
=======================

This archive contains the project source, configuration, documentation, tests,
and assets from the workspace.

Intentionally omitted:
- node_modules and build/cache output
- Git metadata
- local environment files and credentials
- generated test-result output

Create a local .env from .env.example and install dependencies with npm install.
